'use client'
import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import styles from './Consult.module.css'
import { FadeInUp } from '../MotionWrapper'
import { GoogleGenerativeAI } from "@google/generative-ai"

type Msg = { role: 'user' | 'ai'; text: string; time: string }

import { useLanguage } from '../../context/LanguageContext'

// Initialize AI outside to avoid re-initialization on every render
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
const model = genAI.getGenerativeModel({ 
    model: "gemini-1.5-flash",
    systemInstruction: "أنت 'المستشار صقر'، مساعد قانوني ذكي متخصص في الأنظمة واللوائح المعمول بها في المملكة العربية السعودية. مهمتك هي تقديم إرشادات قانونية أولية وتوضيح النصوص القانونية بأسلوب مهني وواضح. تذكر دائماً أنك لست بديلاً عن المحامي المعتمد، ويجب عليك حث المستخدم على استشارة محامٍ في القضايا الجوهرية. أجب باللغة العربية (الفصحى أو العامية السعودية حسب سياق المستخدم). ركز حصرياً على القوانين السعودية."
});

export default function ConsultPage() {
    const { t, language } = useLanguage()
    
    function now() {
        return new Date().toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', { hour: '2-digit', minute: '2-digit' })
    }

    const [msgs, setMsgs] = useState<Msg[]>([
        { role: 'ai', text: t.consult.welcome, time: now() },
    ])
    const [input, setInput] = useState('')
    const [loading, setLoading] = useState(false)
    const bottomRef = useRef<HTMLDivElement>(null)

    useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs])

    const send = async (text?: string) => {
        const q = (text ?? input).trim()
        if (!q || loading) return
        
        if (!process.env.GEMINI_API_KEY) {
            setMsgs(m => [...m, { role: 'ai', text: language === 'ar' ? "عذراً، لم يتم إعداد مفتاح التشغيل الخاص بالذكاء الاصطناعي." : "Sorry, Gemini API Key is not configured.", time: now() }]);
            return;
        }

        setInput('')
        
        const newUserMsg: Msg = { role: 'user', text: q, time: now() }
        setMsgs(prev => [...prev, newUserMsg])
        setLoading(true)

        try {
            // Prepare history for startChat
            // Gemini expects history to alternate between 'user' and 'model'
            // We skip the first AI welcome message as it's not part of the API-managed history
            const history = msgs
                .filter((_, i) => i > 0) 
                .map(m => ({
                    role: m.role === 'user' ? 'user' : 'model',
                    parts: [{ text: m.text }]
                }));

            const chat = model.startChat({
                history: history,
            });

            const result = await chat.sendMessage(q);
            const response = await result.response;
            const aiText = response.text();

            if (aiText) {
                setMsgs(m => [...m, { role: 'ai', text: aiText, time: now() }]);
            } else {
                throw new Error("Empty response from Gemini");
            }
        } catch (err: any) {
            console.error("Gemini API Error:", err);
            // Check for specific safety or blocked errors
            const errorMsg = err?.message?.includes("SAFETY") 
                ? (language === 'ar' ? "عذراً، لا يمكنني الإجابة على هذا السؤال لمخالفته سياسات السلامة." : "Sorry, I cannot answer this due to safety policies.")
                : t.consult.error;
                
            setMsgs(m => [...m, { role: 'ai', text: errorMsg, time: now() }]);
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="page-section" style={{ paddingBottom: 40 }}>
            <div className="container">
                <FadeInUp>
                    <div className="page-header" style={{ textAlign: 'center', marginBottom: '40px' }}>
                        <div className="badge badge-gold" style={{ marginBottom: 16 }}>{t.consult.badge}</div>
                        <h1 className="section-title">{t.consult.title}</h1>
                        <p className="section-subtitle" style={{ margin: '0 auto' }}>
                            {t.consult.subtitle}
                        </p>
                    </div>
                </FadeInUp>

                <motion.div
                    className={styles.chatWrapper}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2, duration: 0.5 }}
                >
                    {/* Disclaimer */}
                    <div className={styles.disclaimer}>
                        {t.consult.disclaimer.split(t.consult.lawyersLink)[0]}
                        <a href="/lawyers" style={{ color: 'var(--primary)', textDecoration: 'underline' }}>{t.consult.lawyersLink}</a>
                        {t.consult.disclaimer.split(t.consult.lawyersLink)[1]}
                    </div>

                    {/* Messages */}
                    <div className={styles.messages}>
                        <AnimatePresence mode="popLayout">
                            {msgs.map((m, i) => (
                                <motion.div
                                    key={i}
                                    className={`${styles.msgRow} ${m.role === 'user' ? styles.userRow : ''}`}
                                    initial={{ opacity: 0, y: 10, scale: 0.97 }}
                                    animate={{ opacity: 1, y: 0, scale: 1 }}
                                    transition={{ duration: 0.3 }}
                                    layout
                                >
                                    {m.role === 'ai' && <div className={styles.avatar}>⚖️</div>}
                                    <div className={`${styles.bubble} ${m.role === 'user' ? styles.userBubble : styles.aiBubble}`}>
                                        <p className={styles.bubbleText}>{m.text}</p>
                                        <span className={styles.bubbleTime}>{m.time}</span>
                                    </div>
                                </motion.div>
                            ))}
                        </AnimatePresence>

                        {loading && (
                            <motion.div
                                className={styles.msgRow}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                            >
                                <div className={styles.avatar}>⚖️</div>
                                <div className={styles.aiBubble} style={{ padding: '16px 20px' }}>
                                    <div className={styles.typing}>
                                        <span /><span /><span />
                                    </div>
                                </div>
                            </motion.div>
                        )}
                        <div ref={bottomRef} />
                    </div>

                    {/* Suggestions */}
                    {msgs.length < 3 && (
                        <motion.div
                            className={styles.suggestions}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.4, duration: 0.4 }}
                        >
                            {t.consult.suggestions.map((s: string) => (
                                <button key={s} className={styles.sugBtn} onClick={() => send(s)}>{s}</button>
                            ))}
                        </motion.div>
                    )}

                    {/* Input */}
                    <div className={styles.inputRow}>
                        <input
                            className={styles.chatInput}
                            placeholder={t.consult.placeholder}
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            onKeyDown={e => { if (e.key === 'Enter') { send() } }}
                        />
                        <button className={styles.sendBtn} onClick={() => send()} disabled={!input.trim() || loading}>
                            {loading ? '⏳' : '←'}
                        </button>
                    </div>
                    <p style={{ 
                        fontSize: '0.75rem', 
                        textAlign: 'center', 
                        marginTop: '12px', 
                        color: 'var(--text-muted)',
                        opacity: 0.8
                    }}>
                        {t.consult.note}
                    </p>
                </motion.div>
            </div>
        </div>
    )
}
